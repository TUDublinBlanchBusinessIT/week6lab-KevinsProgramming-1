<FORM method="POST" action="/customers/create"> @csrf
     Enter your first name:<input type="text" name="firstname"><br>
     Enter your surname:<input type="text" name="surname"><br>
     <input type="submit">
</FORM>